// 小程序配置
export default{
    // TODO 域名（本地调试也需要在这里添加）
    domain:'www.gptcms.cn',
    wid:'1',
}