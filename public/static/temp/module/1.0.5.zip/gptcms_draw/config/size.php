<?php

return [
	[
		"title" => "头像",
		"size" => "1:1"
	],
	[
		"title" => "电脑壁纸",
		"size" => "16:9"
	],
	[
		"title" => "文章配图",
		"size" => "4:3"
	],
	[
		"title" => "社交媒体",
		"size" => "3:4"
	],
	[
		"title" => "宣传海报",
		"size" => "9:16"
	],
];
