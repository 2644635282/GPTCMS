<?php

namespace app\gptcms_draw\controller;

use app\BaseController;
use think\facade\Db;
use think\Request;
use think\facade\Session;
use app\gptcms\model\SmsModel;

class BaseApi extends BaseController
{
    protected $req;
    protected $user;
    protected $wid;
    protected $token;


    public function  __construct(Request $request){
        $this->req = $request;
        $this->host  = $request->host();
        $url  = $request->url();
        $this->token = $this->req->header('token');
        $this->wid = $this->req->header('wid');

        $platform = platform();
        if($platform == 'mpapp'){ //微信小程序
            $this->user = Db::table('kt_gptcms_common_user')->where([['wid', '=', $this->wid],['xcx_token', '=', $this->token]])->find();
        }else{
            $this->user = Db::table('kt_gptcms_common_user')->where([['wid', '=', $this->wid],['token', '=', $this->token], ['expire_time', '>',time()]])->find();
        }
        
        if($this->user){
            $this->uid = $this->user['id'];
            Session::set('uid',$this->user['id']);
        } 
        Session::set('wid',$this->wid);
    }
}