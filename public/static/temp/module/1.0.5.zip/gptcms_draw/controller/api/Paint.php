<?php

namespace app\gptcms_draw\controller\api;
use app\gptcms_draw\controller\BaseApi;
use app\gptcms\model\CommonModel;
use think\facade\Db;
use think\facade\Session;
use app\gptcms\model\ApishopModel;

class Paint extends BaseApi
{
    private $expend = 0;
    private $vip;
    //获取随机描述词
    public function getStyle()
    {
        $wid = Session::get("wid");
        $style = Db::table("kt_gptcms_draw_style")->field('id,title,tp_url,desc,xh,vip_status,c_time')->where('wid',$wid)->where("status",1)->order("xh","desc")->select();
        
        return success("风格列表",$style);
    } 
    //获取随机描述词
    public function getRandDesc()
    {
        $wid = Session::get("wid");
        $str = '';
        $desc = Db::table("kt_gptcms_draw_desclexicon")->where('wid',$wid)->column("content");
        if($desc){
            $str = $desc[array_rand($desc)];
        }
        return success("随机描述词",$str);
    }
    /**
     * 获取消耗条数
     */
    public function getExtend()
    {
        $wid = Session::get("wid");
        $user = $this->user;
        $vip = 0;
        $expend = 0;
        if(strtotime($user['vip_expire']) > time()){ //会员未到期
            $vip = 1;
        }
        $lxmj_charging = Db::table('kt_gptcms_system')->where(['wid'=>$wid])->value('lxmj_charging')?:0;
        if($lxmj_charging){ //如果开启灵犀-MJ单独计费,不能使用vip
            $vip = 0;
        }
        if(!$vip){
            $expend = CommonModel::getExpend('paint',"linkerai_mj");//获取消耗条数
        }
        return success('消耗条数',$expend);
    }
    /**
     * 获取尺寸
     */
    public function getSize()
    {
        return success("尺寸规格",config("size"));
    }

	/**
     * 历史记录
     */
    public function msgs()
    {
        $wid = Session::get('wid');
        $user = $this->user;
        $where = [];
        $where[] = ['wid','=',$wid];
        $where[] = ['common_id','=',$user['id']];

        $msgList = Db::table('kt_gptcms_draw_msg')->field('id,message,response,chatmodel,c_time')->where($where)->order('id asc')->select();
        $msgs = [];
        foreach ($msgList as $key => $msg) {
            $msgs[] = [
                'id' => $msg['id'],
                'role' => '我',
                'content' => $msg['message'],
                'is_mj' => 0, 
            ];
            $is_mj = 0;
            if($msg["chatmodel"] == "linkerai_mj" && $msg["c_time"] + 5400 > time()){
                if(!in_array($msg["message"], ["U1","U2","U3","U4","V1","V2","V3","V4"])) $is_mj = 1;
            }
            $msgs[] = [
                'id' => $msg['id'],
                'role' => '助手',
                'content' => $msg['response'],
                'is_mj' => $is_mj, 
            ];
        }
        return success('获取成功',$msgs);
    }

    /**
     * 清除历史记录
     */
    public function delMsgs()
    {
        $wid = Session::get('wid');
        $user = $this->user;
        if(!$user) return error('用户不存在');

        Db::table('kt_gptcms_draw_msg')->where(['wid'=>$wid,'common_id'=>$user['id']])->delete();
        return success('操作成功,已删除');
    }
    /**
     * 下载
     */
    public function getDownloadExtend()
    {
        return success("下载消耗条数",1);
    }
    /**
     * 下载
     */
    public function download()
    {
        $wid = Session::get('wid');
        $tp =  $this->req->param('tp');
        if(!$tp) return error("请输入图片地址");
        if($this->user['residue_degree'] < 1) return error("剩余条数不足");
        Db::table("kt_gptcms_common_user")->where("id",$this->user["id"])->update([
                "residue_degree" => $this->user['residue_degree'] - 1
            ]);
        ob_start(); 
        $filename = basename($tp);
        $size=readfile($tp);
        header( "Content-type:  application/octet-stream "); 
        header( "Accept-Ranges:  bytes "); 
        header( "Content-Disposition:  attachment;  filename= {$tp}"); 
        header( "Accept-Length: " .$size);
        exit();
    }
    /**
     * getMsgReult
     */
    public function getMsgReult()
    {
        $wid = Session::get('wid');
        $msgid = $this->req->param('msgid');
        $res = Db::table('kt_gptcms_draw_msg')->find($msgid);
        if(!$res) return error('不存在');
        if($res['status'] == 0) return success("图片生成失败");
        if($res['status'] == 1) return success("图片生成中..");
        if($res['status'] == 2){
            $msgs = Db::table('kt_gptcms_draw_msg')->where("pid",$msgid)->select()->toArray();
            if(count($msgs) == 4){
                $list = [];
                if($msgs[0]["response"]) $list[] = $msgs[0]["response"];
                if($msgs[1]["response"]) $list[] = $msgs[1]["response"];
                if($msgs[2]["response"]) $list[] = $msgs[2]["response"];
                if($msgs[3]["response"]) $list[] = $msgs[3]["response"];
                if(count($list) == 4) return success("图片生成成功",$list);
            }
        } ;
        return success("图片生成中..");
    }
     /**
     * send 画同款
     */
    public function sendSame()
    {
        $wid = Session::get('wid');
        $user = $this->user;
        if($user['status'] != 1){
            $this->outError('账号已停用');
        }
        
        $vip = 0;
        if(strtotime($user['vip_expire']) > time()){ //会员未到期
            $vip = 1;
        }
        $lxmj_charging = Db::table('kt_gptcms_system')->where(['wid'=>$wid])->value('lxmj_charging')?:0;
        $config = Db::table('kt_gptcms_gptpaint_config')->where("wid",$wid)->find();
        switch ($config["draw_channel"]) {
            case 7:
                $paintModel = "apishop";
                break;
            case 6:
                $paintModel = "linkerai_mj";
                break;
            default:
                $paintModel = "linkerai_mj";
                break;
        }
        if($lxmj_charging){ //如果开启灵犀-MJ单独计费,不能使用vip
            $vip = 0;
        }
        if(!$vip){
            $this->expend = $expend = CommonModel::getExpend('paint',$paintModel);//获取消耗条数
            if($user['residue_degree'] < $expend){ //余数不足
                $zdz_remind = Db::table('kt_gptcms_system')->where('wid',$wid)->value('zdz_remind');
                return error($zdz_remind?:'剩余条数不足');
            }
        }
        $this->vip = $vip;
        $id = $this->req->param('id');
        if(!$id) return error("请选择作品");
        $msgtp =  Db::table('kt_gptcms_draw_msgtp')->find($id);
        $msg = Db::table('kt_gptcms_draw_msg')->find($msgtp['msg_id']);

        $message = $msgtp["message"];
        $style = $msg["style"];
        $size = $msg["size"];
        // $prompt = $message . " ," . $style . " --ar ". $size;

        $msgId = Db::table('kt_gptcms_draw_msg')->insertGetId([
                        'wid' => $wid,
                        'common_id' => $this->user['id'],
                        'un_message' => $message,
                        'message' => $message,
                        'imageurl' => $msg['imageurl'],
                        'mode' => $msg['mode'],
                        // 'un_response' => '',
                        // 'response' => '',
                        'total_tokens' => mb_strlen($message),
                        'chatmodel' => "linkerai_mj",
                        'sync_status' => 1,
                        'c_time' => time(),
                        'u_time' => time(),
                        "style" => $style,
                        "size"  => $size,
                    ]);
        $mode = $msg['mode'] ?: "v 5.2";
        // $res = $this->linkeraiMjTask('linkerai_mj',$prompt,$msgId,$msg['imageurl']);
        switch ($paintModel) {
            case "linkerai_mj":
                $prompt = $message . " ," . $style. " --ar ". $size." --".$mode;
                $res = $this->linkeraiMjTask('linkerai_mj',$prompt,$msgId,$msg['imageurl']);
                break;
            case "apishop":
                $prompt = $message . " ," . $style;
                $res = $this->apishopTask($prompt,$msgId,$size,$msg['imageurl'],$mode);
                break;
        }
        if(!$res){
            Db::table('kt_gptcms_draw_msg')->where('id',$msgId)->update([
                'status' => 0,
                'u_time' => time()
            ]);
            return error("图片生成失败");
        }
        $this->updateExpend();
        return success("图片生成中",['msgid'=>$msgId]);
    }
    /**
     * send
     */
    public function send()
    {
    	$wid = Session::get('wid');
        $user = $this->user;
        if($user['status'] != 1){
            $this->outError('账号已停用');
        }
        
        $vip = 0;
        if(strtotime($user['vip_expire']) > time()){ //会员未到期
            $vip = 1;
        }
        $lxmj_charging = Db::table('kt_gptcms_system')->where(['wid'=>$wid])->value('lxmj_charging')?:0;
        if($lxmj_charging){ //如果开启灵犀-MJ单独计费,不能使用vip
            $vip = 0;
        }
        $config = Db::table('kt_gptcms_gptpaint_config')->where("wid",$wid)->find();
        switch ($config["draw_channel"]) {
            case 7:
                $paintModel = "apishop";
                break;
            case 6:
                $paintModel = "linkerai_mj";
                break;
            default:
                $paintModel = "linkerai_mj";
                break;
        }
        if(!$vip){
            $this->expend = $expend = CommonModel::getExpend('paint',$paintModel);//获取消耗条数
            if($user['residue_degree'] < $expend){ //余数不足
                $zdz_remind = Db::table('kt_gptcms_system')->where('wid',$wid)->value('zdz_remind');
                return error($zdz_remind?:'剩余条数不足');
            }
        }
        $this->vip = $vip;
        $message = $this->req->param('message');
        $imageurl = $this->req->param('imageurl') ?: "";
        $style_id = $this->req->param('style_id');
        $mode = $this->req->param('mode') ?: "v 5.2";
        if(!$style_id) return error("请选择风格");
        $style = Db::table('kt_gptcms_draw_style')->find($style_id);
        if($vip && !$style["vip_status"]) return error("请先开通会员");
        if(!$message && !$imageurl){
            return error('描述与上传图片至少填写一个');
        }
        $size = $this->req->param('size');
        if(!$size) return error("请选择尺寸");
        

        $msgId = Db::table('kt_gptcms_draw_msg')->insertGetId([
                        'wid' => $wid,
                        'common_id' => $this->user['id'],
                        'un_message' => $message,
                        'message' => $message,
                        'imageurl' => $imageurl,
                        'mode' => $mode,
                        // 'un_response' => '',
                        // 'response' => '',
                        'total_tokens' => mb_strlen($message),
                        'chatmodel' => $paintModel,
                        'sync_status' => 0,
                        'c_time' => time(),
                        'u_time' => time(),
                        "style" => $style["desc"],
                        "size"  => $size,
                    ]);
        
        
        switch ($paintModel) {
            case "linkerai_mj":
                $prompt = $message . " ," . $style["desc"] . " --ar ". $size ." --".$mode;
                $res = $this->linkeraiMjTask('linkerai_mj',$prompt,$msgId,$imageurl);
                break;
            case "apishop":
                $prompt = $message . " ," . $style["desc"];
                $res = $this->apishopTask($prompt,$msgId,$size,$imageurl,$mode);
                break;
        }
        
        if(!$res){
            Db::table('kt_gptcms_draw_msg')->where('id',$msgId)->update([
                'status' => 0,
                'u_time' => time()
            ]);
            return error("图片生成失败");
        }
        $this->updateExpend();
        return success("图片生成中",['msgid'=>$msgId]);
    }
    //apishop
    private function apishopTask($message,$msgId,$pratio,$imageurl,$mode="v 5.2")
    {
        $wid = Session::get('wid');
        $config = Db::table('kt_gptcms_gptpaint_config')->json(['apishop'])->where('wid',$wid)->find();
        $apishopconfig = $config["apishop"];
        if(!$apishopconfig || !$apishopconfig["appkey"] || !$apishopconfig["appsecret"]) return '';
        $apiurl = '';
        $data = [
            "imageurl" => $imageurl,
        ];
        switch ($apishopconfig["model"]) {
            case 'mj_c1_fast':
                $data["mode"] = "fast";
                $data["prompt"] = $message . " --ar ". $pratio . "--".$mode;
                $data["notifyhook"] = $this->req->domain()."/gptcms_draw/api/paintnotify/apishopmjc1";
                $apiurl = "/apishop/api/c1paint/send";
                break;
            case 'mj_c1_mix':
                $data["mode"] = "mix";
                $data["prompt"] = $message . " --ar ". $pratio . "--".$mode;
                $data["notifyhook"] = $this->req->domain()."/gptcms_draw/api/paintnotify/apishopmjc1";
                $apiurl = "/apishop/api/c1paint/send";
                break;
            case 'mj_c1_relax':
                $data["prompt"] = $message . " --ar ". $pratio . "--".$mode;
                $data["mode"] = "relax";
                $data["notifyhook"] = $this->req->domain()."/gptcms_draw/api/paintnotify/apishopmjc1";
                $apiurl = "/apishop/api/c1paint/send";
                break;
            case 'mj_c2':
                $data["mode"] = $mode;
                $data["prompt"] = $message;
                $data["pratio"] = $pratio;
                $data["notifyhook"] = $this->req->domain()."/gptcms_draw/api/paintnotify/apishopmjc2";
                $apiurl = "/apishop/api/c2paint/send";
                break; 
        }
        $res = (new ApishopModel($apishopconfig["appkey"],$apishopconfig["appsecret"]))->create($apiurl,$data);
        if($res && isset($res["status"]) && $res["status"] == "success"){
            $task_id = $res["data"]["task_id"];
            Db::table('kt_gptcms_draw_notify')->insert([
                                'wid' => $wid,
                                'task_id' => $task_id,
                                'chatmodel' => 'apishop',
                                'msgid' => $msgId,
                                'c_time' => date("Y-m-d H:i:s"),
                            ]);
            return $task_id;
        }
        return '';
    }
    private function linkeraiMjTask($type,$message,$msgId,$imageurl)
    {
        $wid = Session::get('wid');
        $config = Db::table('kt_gptcms_gpt_config')->json(['linkerai'])->where('wid',$wid)->find();
        if(!$config )  return '';
        $aiconfig = $config['linkerai'];
        $ktadmin = new \Ktadmin\LinkerAi\Ktadmin(['channel'=>7,'api_key'=>$aiconfig['api_key']]);
        $callback_url = $this->req->domain()."/gptcms_draw/api/paintnotify/linkeraimj";
        $res = $ktadmin->images()->send($message,$callback_url,$imageurl);
        if($res && is_array($res) && $res['code'] == 1){
             Db::table('kt_gptcms_draw_notify')->insert([
                                'wid' => $wid,
                                'task_id' => $res['result'],
                                'chatmodel' => 'linkerai_mj',
                                'msgid' => $msgId,
                                'c_time' => date("Y-m-d H:i:s"),
                            ]);
            return $res['result'];
        } 
        return '';
    }

    private function updateExpend()
    {
        if($this->expend){
            Db::table("kt_gptcms_common_user")->where("id",$this->user["id"])->update([
                "residue_degree" => $this->user['residue_degree'] - $this->expend
            ]);
        }   
        return "ok";
    }


}