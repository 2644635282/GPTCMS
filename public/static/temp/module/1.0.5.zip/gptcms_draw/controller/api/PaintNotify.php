<?php
declare (strict_types = 1);

namespace app\gptcms_draw\controller\api;
use app\gptcms_draw\controller\BaseApi;
use think\facade\Db;
use think\facade\Session;
use think\facade\Log;
use app\gptcms\model\MediaModel;
use app\gptcms\model\ApishopModel;

class PaintNotify extends BaseApi
{
    public function apishopmjc2()
    {
        $task_id = $this->req->param('task_id');
        if(!$task_id) die("ERROR");
        $ImagePath = $this->req->param('imageUrl');
        $notify = Db::table('kt_gptcms_draw_notify')->where('task_id',$task_id)->where('status',0)->order("c_time","asc")->find();
        if(!$notify) die;
        Db::table('kt_gptcms_draw_notify')->where('id',$notify['id'])->update([
            'status' => 1,
            'u_time' => date("Y-m-d H:i:s"),
        ]);
        $wid = $notify['wid'];  
        // $img = MediaModel::uploadPaint($wid,$ImagePath,'linkerai_mj');
        Db::table('kt_gptcms_draw_msg')->where('id',$notify['msgid'])->update([
                        'un_response' => $ImagePath,
                        // 'response' => $img['img'],
                        'response' => $ImagePath,
                        'status' => 2,
                        'u_time' => time()
                    ]);
        $msg = Db::table('kt_gptcms_draw_msg')->find($notify['msgid']);
        if(in_array($msg["message"], ["U1","U2","U3","U4"])){
            $this->saveMsgtp($msg);
        }else{
            $this->apishopC2MjUv($msg,"U1",$task_id);
            $this->apishopC2MjUv($msg,"U2",$task_id);
            $this->apishopC2MjUv($msg,"U3",$task_id);
            $this->apishopC2MjUv($msg,"U4",$task_id);
        }
        echo "SUCCESS";
        die;
    }
    private function apishopC2MjUv($mjmsg,$u,$task_id)
    {
        $wid = $mjmsg["wid"];
        $chatmodel = "apishop";
        $message = $u;
        $msgId = Db::table('kt_gptcms_draw_msg')->insertGetId([
                        'wid' => $wid,
                        'common_id' => $mjmsg['common_id'],
                        'un_message' => $message,
                        'message' => $message,
                        // 'un_response' => '',
                        // 'response' => '',
                        'total_tokens' => mb_strlen($message),
                        'chatmodel' => $chatmodel,
                        'sync_status' => 0,
                        "style" => $mjmsg["style"],
                        "size"  => $mjmsg["size"],
                        'pid' => $mjmsg["id"],
                        'imageurl' => $mjmsg['imageurl'],
                        'c_time' => time(),
                        'u_time' => time(),
                    ]);

        $config = Db::table('kt_gptcms_gptpaint_config')->json(['apishop'])->where('wid',$wid)->find();
        $apishopconfig = $config["apishop"];
        if(!$apishopconfig || !$apishopconfig["appkey"] || !$apishopconfig["appsecret"]) return '';
        $apiurl = '';
        $data = [
            "pcurl" => $mjmsg["un_response"]
        ];
        switch ($u) {
            case 'U1':
                $position = "nw";
                break;
             case 'U2':
                $position = "ne";
                break;
             case 'U3':
                $position = "sw";
                break;
             case 'U4':
                $position = "se";
                break;

        }
        $data["position"] = $position;
        $data["notifyhook"] = $this->req->domain()."/gptcms_draw/api/paintnotify/apishopmjc2";
        $apiurl = "/apishop/api/c2paint/uv";
        $res = (new ApishopModel($apishopconfig["appkey"],$apishopconfig["appsecret"]))->create($apiurl,$data);
        if($res && isset($res["status"]) && $res["status"] == "success"){
            $task_id = $res["data"]["task_id"];
            Db::table('kt_gptcms_draw_notify')->insert([
                                'wid' => $wid,
                                'task_id' => $task_id,
                                'chatmodel' => 'apishop',
                                'msgid' => $msgId,
                                'c_time' => date("Y-m-d H:i:s"),
                            ]);
            return $task_id;
        }
        return error("生成图片失败");

    }
    public function apishopmjc1()
    {
        $task_id = $this->req->param('task_id');
        if(!$task_id) die("ERROR");
        $ImagePath = $this->req->param('imageUrl');
        $notify = Db::table('kt_gptcms_draw_notify')->where('task_id',$task_id)->where('status',0)->order("c_time","asc")->find();
        if(!$notify) die;
        Db::table('kt_gptcms_draw_notify')->where('id',$notify['id'])->update([
            'status' => 1,
            'u_time' => date("Y-m-d H:i:s"),
        ]);
        $wid = $notify['wid'];  
        // $img = MediaModel::uploadPaint($wid,$ImagePath,'linkerai_mj');
        Db::table('kt_gptcms_draw_msg')->where('id',$notify['msgid'])->update([
                        'un_response' => $ImagePath,
                        // 'response' => $img['img'],
                        'response' => $ImagePath,
                        'status' => 2,
                        'u_time' => time()
                    ]);
        $msg = Db::table('kt_gptcms_draw_msg')->find($notify['msgid']);
        if(in_array($msg["message"], ["U1","U2","U3","U4"])){
            $this->saveMsgtp($msg);
        }else{
            $this->apishopC1MjUv($msg,"U1",$task_id);
            $this->apishopC1MjUv($msg,"U2",$task_id);
            $this->apishopC1MjUv($msg,"U3",$task_id);
            $this->apishopC1MjUv($msg,"U4",$task_id);
        }
        echo "SUCCESS";
        die;
    }
    private function apishopC1MjUv($mjmsg,$u,$task_id)
    {
        $wid = $mjmsg["wid"];
        $chatmodel = "apishop";
        $message = $u;
        $msgId = Db::table('kt_gptcms_draw_msg')->insertGetId([
                        'wid' => $wid,
                        'common_id' => $mjmsg['common_id'],
                        'un_message' => $message,
                        'message' => $message,
                        // 'un_response' => '',
                        // 'response' => '',
                        'total_tokens' => mb_strlen($message),
                        'chatmodel' => $chatmodel,
                        'sync_status' => 0,
                        "style" => $mjmsg["style"],
                        "size"  => $mjmsg["size"],
                        'pid' => $mjmsg["id"],
                        'imageurl' => $mjmsg['imageurl'],
                        'c_time' => time(),
                        'u_time' => time(),
                    ]);

        $config = Db::table('kt_gptcms_gptpaint_config')->json(['apishop'])->where('wid',$wid)->find();
        $apishopconfig = $config["apishop"];
        if(!$apishopconfig || !$apishopconfig["appkey"] || !$apishopconfig["appsecret"]) return '';
        $apiurl = '';
        $data = [
            "task_id" => $task_id,
        ];

        $data["prompt"] = $message;
        $data["notifyhook"] = $this->req->domain()."/gptcms_draw/api/paintnotify/apishopmjc1";
        $apiurl = "/apishop/api/c1paint/uv";
        $res = (new ApishopModel($apishopconfig["appkey"],$apishopconfig["appsecret"]))->create($apiurl,$data);
        if($res && isset($res["status"]) && $res["status"] == "success"){
            $task_id = $res["data"]["task_id"];
            Db::table('kt_gptcms_draw_notify')->insert([
                                'wid' => $wid,
                                'task_id' => $task_id,
                                'chatmodel' => 'apishop',
                                'msgid' => $msgId,
                                'c_time' => date("Y-m-d H:i:s"),
                            ]);
            return $task_id;
        }
        return error("生成图片失败");

    }
	public function linkeraimj()
	{
		$id = $this->req->param('id');
		$status = $this->req->param('status');
		if(!$id) die("ERROR");
		if($status != "SUCCESS") die("执行中");
		$ImagePath = $this->req->param('imageUrl');
		$notify = Db::table('kt_gptcms_draw_notify')->where('task_id',$id)->where('status',0)->order("c_time","asc")->find();
		if(!$notify) die;
		Db::table('kt_gptcms_draw_notify')->where('id',$notify['id'])->update([
			'status' => 1,
			'u_time' => date("Y-m-d H:i:s"),
		]);
		$wid = $notify['wid'];
		// $img = MediaModel::uploadPaint($wid,$ImagePath,'linkerai_mj');
		Db::table('kt_gptcms_draw_msg')->where('id',$notify['msgid'])->update([
                        'un_response' => $ImagePath,
                        // 'response' => $img['img'],
                        'response' => $ImagePath,
                        'status' => 2,
                        'u_time' => time()
                    ]);
		$msg = Db::table('kt_gptcms_draw_msg')->find($notify['msgid']);
		if(in_array($msg["message"], ["U1","U2","U3","U4"])){
			$this->saveMsgtp($msg);
		}else{
			$this->linkeraiMjUv($msg,"U1");
			$this->linkeraiMjUv($msg,"U2");
			$this->linkeraiMjUv($msg,"U3");
			$this->linkeraiMjUv($msg,"U4");
		}
		echo "SUCCESS";
		die;
	}
 	private function saveMsgtp($mjmsg)
 	{
 		$pmsg = Db::table('kt_gptcms_draw_msg')->find($mjmsg['pid']);
 		$msgtpId = Db::table('kt_gptcms_draw_msgtp')->insertGetId([
 			"wid"=>$mjmsg["wid"],
 			"common_id"=>$mjmsg["common_id"],
 			"msg_id"=>$mjmsg["id"],
 			"message" => $pmsg["message"],
 			"image" => $mjmsg["response"],
 			"c_time" =>  date("Y-m-d H:i:s"),
 			"u_time" =>  date("Y-m-d H:i:s"),
 		]);
        Db::table('kt_gptcms_syncpaint')->insertGetId([
            "wid"=>$mjmsg["wid"],
            "msg_id"=>$mjmsg["id"],
            "source_type" => 2,
            "mj_url" => $mjmsg["response"],
            "c_time" =>  date("Y-m-d H:i:s"),
            "u_time" =>  date("Y-m-d H:i:s"),
        ]);
 		return "ok";
 	}
    private function linkeraiMjUv($mjmsg,$u)
    {
        $wid = $mjmsg["wid"];
        $chatmodel = "linkerai_mj";
        $message = $u;
        $taskid = Db::table('kt_gptcms_draw_notify')->where("msgid",$mjmsg["id"])->value("task_id");
        $type = "";
        $index = 0;
        switch ($message) {
             case 'U1':
                $type = "upscale";
                $index = "1";
                break;
             case 'U2':
                $type = "upscale";
                $index = "2";
                break;
             case 'U3':
                $type = "upscale";
                $index = "3";
                break;
             case 'U4':
                $type = "upscale";
                $index = "4";
                break;
             case 'V1':
                $type = "variation";
                $index = "1";
                break;
             case 'V2':
                $type = "variation";
                $index = "2";
                break;
             case 'V3':
                $type = "variation";
                $index = "3";
                break;
             case 'V4':
                $type = "variation";
                $index = "4";
                break;
            default:
                return error("请输入合规的类型");
                break;
        }
        $msgId = Db::table('kt_gptcms_draw_msg')->insertGetId([
                        'wid' => $wid,
                        'common_id' => $mjmsg['common_id'],
                        'un_message' => $message,
                        'message' => $message,
                        // 'un_response' => '',
                        // 'response' => '',
                        'total_tokens' => mb_strlen($message),
                        'chatmodel' => $chatmodel,
                        'sync_status' => 0,
                        "style" => $mjmsg["style"],
                        "size"  => $mjmsg["size"],
                        'pid' => $mjmsg["id"],
                        'imageurl' => $mjmsg['imageurl'],
                        'c_time' => time(),
                        'u_time' => time(),
                    ]);

        $config = Db::table('kt_gptcms_gpt_config')->json(['linkerai'])->where('wid',$wid)->find();
        $aiconfig = $config['linkerai'];
        $ktadmin = new \Ktadmin\LinkerAi\Ktadmin(['channel'=>7,'api_key'=>$aiconfig['api_key']]);
        $callback_url = $this->req->domain()."/gptcms_draw/api/paintnotify/linkeraimj";

        $res = $ktadmin->images()->uv($taskid,$type,$index,$callback_url);
        if($res && is_array($res) && $res['code'] == 1){
             Db::table('kt_gptcms_draw_notify')->insert([
                                'wid' => $wid,
                                'task_id' => $res['result'],
                                'chatmodel' => 'linkerai_mj',
                                'msgid' => $msgId,
                                'c_time' => date("Y-m-d H:i:s"),
                            ]);
            return success("图片生成中",['msgid'=>$msgId]);
        }
        return error("生成图片失败");
    }
}


