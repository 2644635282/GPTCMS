<?php

namespace app\gptcms_draw\controller\api;
use app\gptcms_draw\controller\BaseApi;
use app\gptcms\model\CommonModel;
use think\facade\Db;
use think\facade\Session;

class Square extends BaseApi
{
	public function getClassfy()
	{
		$wid = Session::get("wid");
		$data = [
			[
				"id" => 0,
				"title" => "全部"
			],
			[
				"id" => -1,
				"title" => "热门"
			],
		];
		$res = Db::table("kt_gptcms_draw_classify")->field("id,title")->where("wid",$wid)->order("sort","desc")->select()->toArray();
		$data = array_merge($data,$res);
		return success("分类",$data);
	}

	public function list()
	{
		$wid = Session::get("wid");
		$page = $this->req->param('page/d') ?: 1;
		$size = $this->req->param('size/d') ?: 10;
		$classify_id = $this->req->param('classify_id/d');
		$title = $this->req->param('title');
		$res = Db::table("kt_gptcms_draw_msgtp")->field("id,message,classfy_id,title,image,msg_id")->where("wid",$wid)->where("open_status",1);
		if($classify_id && $classify_id == -1) $res->where("hot_status",1);
		if($classify_id && $classify_id != -1) $res->where("classfy_id",$classify_id);
		if($title) $res->where("title","like","%".$title."%");
		$data = [];
		$data['page'] = $page;
		$data['size'] = $size;
		$data['count'] = $res->count();
		$data["item"] = $res->page($page,$size)->order("u_time","desc")->filter(function($r){
			$r["size"] = Db::table("kt_gptcms_draw_msg")->where("id",$r["msg_id"])->value("size");
			return $r;
		})->select();
		return success("广场分类作品",$data);
	}
	public function hotList()
	{
		$wid = Session::get("wid");
		$title = $this->req->param('title');
		$res = Db::table("kt_gptcms_draw_msgtp")->field("id,message,classfy_id,title,image,msg_id")->where("wid",$wid)->where("open_status",1)->where("hot_status",1);
		if($title) $res->where("title","like","%".$title."%");
		$res = $res->order("u_time","desc")->filter(function($r){
			$r["size"] = Db::table("kt_gptcms_draw_msg")->where("id",$r["msg_id"])->value("size");
			return $r;
		})->select();
		return success("广场顶部大图",$res);
	}


}