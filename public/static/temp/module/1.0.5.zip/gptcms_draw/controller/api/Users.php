<?php

namespace app\gptcms_draw\controller\api;
use app\gptcms_draw\controller\BaseApi;
use think\facade\Db;
use think\facade\Session;
use Ramsey\Uuid\Uuid;
use think\facade\Log;
use think\facade\Cache;

class Users extends BaseApi
{
	public function tpList()
	{
		$wid = Session::get("wid");
		$page = $this->req->param('page/d') ?: 1;
		$size = $this->req->param('size/d') ?: 10;
		$res = Db::table("kt_gptcms_draw_msgtp")->field("id,message,classfy_id,title,image,msg_id")->where("wid",$wid)->where("common_id",$this->user["id"])->where("del_status",0);
		$data = [];
		$data['page'] = $page;
		$data['size'] = $size;
		$data['count'] = $res->count();
		$data["item"] = $res->page($page,$size)->order("u_time","desc")->filter(function($r){
			$r["size"] = Db::table("kt_gptcms_draw_msg")->where("id",$r["msg_id"])->value("size");
			return $r;
		})->select();
		return success("广场分类作品",$data);
	}
	public function tpDel()
	{	
		$wid = Session::get("wid");
		$id = $this->req->param('id/a');
		if(!$id) return error("请选择作品");
		$res = Db::table("kt_gptcms_draw_msgtp")->where("wid",$wid)->where("common_id",$this->user["id"])->where("id","in",$id)->update([
			"del_status" => 1
		]);
		if($res) return success("删除成功");
		return error("删除失败");
	}
}