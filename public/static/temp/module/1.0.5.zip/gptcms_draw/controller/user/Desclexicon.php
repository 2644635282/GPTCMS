<?php
declare (strict_types = 1);

namespace app\gptcms_draw\controller\user;
use app\gptcms_draw\controller\BaseUser;
use think\facade\Db;
use think\facade\Session;

class Desclexicon extends BaseUser
{
    public function importData()
    {
        $wid = Session::get("wid");
        $has = Db::table("kt_gptcms_draw_desclexicon")->where("wid",$wid)->find();
        if($has) return error("已有数据, 不可导入");
        $list = config("defaultdata.desclexicon");
        $count = count($list) + 1;
        $i = 0;
        $data  =  array_map(function($r)use($wid,$count,&$i){
            $i++;
            return [
                "wid" => $wid,
                "content" => $r,
                "xh" => $count - $i,
                "c_time" => date("Y-m-d H:i:s"),
                "u_time" => date("Y-m-d H:i:s"),
            ];
        }, $list);
        $res = Db::table("kt_gptcms_draw_desclexicon")->insertAll($data);
        if($res) return success("导入成功");
        return error("导入失败");
    }
	public function list()
    {
    	$wid = Session::get('wid');
    	$page = $this->req->param('page')?:1;
        $size = $this->req->param("size")?:10;
        $content = $this->req->param('content');
        $res = Db::table("kt_gptcms_draw_desclexicon")->where('wid',$wid);
        if($content) $res->where('content',"like","%".$content."%");

    	$data = [];
    	$data['page'] = $page;
    	$data['size'] = $size;
    	$data['count'] = $res->count();
		$data['item'] = $res->page($page,$size)->order("c_time","desc")->select();

    	return success('词库列表',$data);
    }
    public function delete()
    {
    	$wid = Session::get('wid');
    	$id = $this->req->param('id');
    	if(!$id) return error('请选择描述词');
    	$res = Db::table("kt_gptcms_draw_desclexicon")->where('wid',$wid)->where('id',$id)->delete();
    	if(!$res) return error('删除失败');
    	return success('删除成功');
    }
	public function save()
    {
    	$wid = Session::get('wid');
    	$id = $this->req->param('id');
    	$data = [];
    	$data['wid'] = $wid;
    	$data['xh'] = $this->req->param('xh',0);;
    	$data['content'] = $this->req->param('content');
    	if(!$data['content']) return error('请输入内容');
    	if($id){
    		$data['id'] = $id;
    	}else{
    		$data['c_time'] = date("Y-m-d H:i:s");
    	}	
    	$data['u_time'] = date("Y-m-d H:i:s");
    	$res = Db::table("kt_gptcms_draw_desclexicon")->save($data);
    	return success('保存成功');
    }
}