<?php
declare (strict_types = 1);

namespace app\gptcms_draw\controller\user;
use app\gptcms\controller\BaseUser;
use think\facade\Db;
use think\facade\Session;

class Paint extends BaseUser
{
    public function list()
    {
        $wid = Session::get('wid');
        $page = $this->req->param('page/d')?:1;
        $size = $this->req->param("size/d")?:10;
        $nickname = $this->req->param('nickname');
        $message = $this->req->param('message');
        $classfy_id = $this->req->param('classfy_id');
        $res = Db::table("kt_gptcms_draw_msgtp")
               ->alias('c')
               ->field('c.id,c.common_id,c.image,c.open_status,c.hot_status,c.message,c.classfy_id,c.c_time,u.nickname')
               ->leftjoin('kt_gptcms_common_user u','c.common_id=u.id')
               // ->leftjoin('kt_gptcms_draw_msg m','c.msg_id=m.id')
               ->where('c.wid',$wid);
        if($classfy_id)  $res->where("c.classfy_id",$classfy_id);
        if($nickname) $res->where('c.common_id|u.nickname','like','%'.$nickname.'%');
        if($message) $res->where('m.message','like','%'.$message.'%');
        
        $data = [];
        $data['page'] = $page;
        $data['size'] = $size;
        $data['count'] = $res->count();
        $data['item'] = $res->page($page,$size)->order('c.c_time','desc')->filter(function($r){
        	$r["classfy_title"] = "";
        	if($r['classfy_id']) $r["classfy_title"] = Db::table("kt_gptcms_draw_classify")->where("id",$r['classfy_id'])->value("title");
        	return $r;
        })->select();

        return success('作品列表',$data);
    }

    public function delete()
    {
        $wid = Session::get('wid');
        $id = $this->req->param('id');
        if(!$id) return error('请选择作品');
        $res = Db::table("kt_gptcms_draw_msgtp")->where('wid',$wid)->where('id',$id)->delete();
        if(!$res) return error('删除失败');
        return success('删除成功');
    }
    public function hotStatus()
    {
        $wid = Session::get('wid');
        $id = $this->req->param('id');
        if(!$id) return error('请选择作品');
        $hot_status = $this->req->param('hot_status',0);

        $res = Db::table("kt_gptcms_draw_msgtp")->where('wid',$wid)->where('id',$id)->update([
        	"hot_status" => $hot_status,
        	"u_time" => date("Y-m-d H:i:s")
        ]);
        return success('保存成功');
    }
    public function openStatus()
    {
        $wid = Session::get('wid');
        $id = $this->req->param('id');
        if(!$id) return error('请选择作品');
        $open_status = $this->req->param('open_status',0);

        $res = Db::table("kt_gptcms_draw_msgtp")->where('wid',$wid)->where('id',$id)->update([
        	"open_status" => $open_status,
        	"u_time" => date("Y-m-d H:i:s")
        ]);
        return success('保存成功');
    }
    public function title()
    {
        $wid = Session::get('wid');
        $id = $this->req->param('id');
        if(!$id) return error('请选择作品');
        $title = $this->req->param('title',0);

        $res = Db::table("kt_gptcms_draw_msgtp")->where('wid',$wid)->where('id',$id)->update([
        	"title" => $title,
        	"u_time" => date("Y-m-d H:i:s")
        ]);
        return success('保存成功');
    }
    public function classifySet()
    {
        $wid = Session::get('wid');
        $id = $this->req->param('id');
        if(!$id) return error('请选择作品');
        $classfy_id = $this->req->param('classfy_id');
        $res = Db::table("kt_gptcms_draw_msgtp")->where('wid',$wid)->where('id',$id)->update([
        	"classfy_id" => $classfy_id,
        	"u_time" => date("Y-m-d H:i:s")
        ]);
        return success('保存成功');
    }

    public function classify()
    {
        $wid = Session::get('wid');
        $page = $this->req->param('page/d') ?: 1;
        $size = $this->req->param('size/d') ?: 10;
        $res =  Db::table('kt_gptcms_draw_classify')->where('wid',$wid);
        $data['page'] = $page;
        $data['size'] = $size;
        $data['count'] = $res->count();
        $data['item'] = $res->page($page,$size)->order('sort','desc')->select();
        return success('作品分类',$data);
    }
    public function classifyDel()
    {
        $wid = Session::get('wid');
        $id = $this->req->param('id/d');
        if(!$id) return error('请选择分类');
        $has = Db::table('kt_gptcms_draw_msgtp')->where("wid",$wid)->where("classfy_id",$id)->count();
        if($has) return error("请先移除当前分类的作品");
        $res = Db::table('kt_gptcms_draw_classify')->where('id',$id)->where('wid',$wid)->delete();
        if(!$res) return error("删除失败");
        return success("删除成功");
    }
    public function classifySave()
    {
        $wid = Session::get('wid');
        $title = $this->req->param('title');
        if(!$title)  return error("请输入分类名称");
        $sort = $this->req->param('sort') ?: 0;
        $data = [
            'sort' => $sort,
            'title' => $title,
            'u_time' => date("Y-m-d H:i:s")
        ];
        $id = $this->req->param('id/d');
        if($id){
        	$data['id'] = $id;
        } else {
        	$data['c_time'] = date("Y-m-d H:i:s");
        	$data['wid'] = $wid;
        }
        Db::table('kt_gptcms_draw_classify')->save($data);
        return success("保存成功");
    }
}