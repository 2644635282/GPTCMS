<?php
declare (strict_types = 1);

namespace app\gptcms_draw\controller\user;
use app\gptcms_draw\controller\BaseUser;
use think\facade\Db;
use think\facade\Session;

class Style extends BaseUser
{
    public function importData()
    {
        $wid = Session::get("wid");
        $has = Db::table("kt_gptcms_draw_style")->where("wid",$wid)->find();
        if($has) return error("已有数据, 不可导入");
        $list = config("defaultdata.style");

        $data  =  array_map(function($r)use($wid){
            $r["wid"] = $wid;
            $r['tp_url'] = $this->req->domain().$r['tp_url'];
            $r["c_time"] = date("Y-m-d H:i:s");
            $r["u_time"] = date("Y-m-d H:i:s");
            return $r;
        }, $list);
        $res = Db::table("kt_gptcms_draw_style")->insertAll($data);

        if($res) return success("导入成功");
        return error("导入失败");
    }
	public function list()
    {
    	$wid = Session::get('wid');
    	$page = $this->req->param('page/d')?:1;
        $size = $this->req->param("size/d")?:10;
        $res = Db::table("kt_gptcms_draw_style")->where('wid',$wid)->field('id,title,tp_url,desc,xh,vip_status,status,c_time');
    	$data = [];
    	$data['page'] = $page;
    	$data['size'] = $size;
    	$data['count'] = $res->count();
		$data['item'] = $res->page($page,$size)->order('xh','desc')->select();
    	return success('风格列表',$data);
    }
    public function delete()
    {
    	$wid = Session::get('wid');
    	$id = $this->req->param('id');
    	if(!$id) return error('请选择风格');
    	$res = Db::table("kt_gptcms_draw_style")->where('wid',$wid)->where('id',$id)->delete();
    	if(!$res) return error('删除错误');
    	return success('删除成功');
    }
    public function save()
    {
    	$wid = Session::get('wid');
    	$id = $this->req->param('id');
    	$data = [];
    	$data['wid'] = $wid;
    	$data['title'] = $this->req->param('title');
    	$data['xh'] = $this->req->param('xh',0);
    	if(!$data['title']) return error('请输入名称');
    	$data['tp_url'] = $this->req->param('tp_url');
    	$data['desc'] = $this->req->param('desc');
    	if(!$data['desc']) return error('请输入指令');

    	if($id){
    		$data['id'] = $id;

    	}else{
    		$data['c_time'] = date("Y-m-d H:i:s");
    	}	
    	$data['u_time'] = date("Y-m-d H:i:s");
    	$res = Db::table("kt_gptcms_draw_style")->save($data);
    	return success('保存成功');
    }
    public function updateStatus()
    {   
        $wid = Session::get('wid');
        $id = $this->req->param('id');
        $status = $this->req->param('status');
        Db::table('kt_gptcms_draw_style')->where('id',$id)->where('wid',$wid)->update([
            'status' => $status,
            'u_time' => date("Y-m-d H:i:s"),

        ]);
        return success('操作成功');
    }
    public function updateVipStatus()
    {
        $wid = Session::get('wid');
        $id = $this->req->param('id');
        $vip_status = $this->req->param('vip_status');
        Db::table('kt_gptcms_draw_style')->where('id',$id)->where('wid',$wid)->update([
            'vip_status' => $vip_status,
            'u_time' => date("Y-m-d H:i:s"),

        ]);
        return success('操作成功');
    }
    public function detail()
    {
    	$wid = Session::get('wid');
    	$id = $this->req->param('id');
    	if(!$id) return error('请选择风格');
    	$res = Db::table("kt_gptcms_draw_style")->field('id,title,tp_url,desc,xh,vip_status,status,c_time')->where('wid',$wid)->find($id);

    	return success('风格详情',$res);
    }
}