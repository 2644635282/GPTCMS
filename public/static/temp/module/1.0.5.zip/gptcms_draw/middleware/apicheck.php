<?php

declare (strict_types = 1);

namespace app\gptcms_draw\middleware;
use think\facade\Db;
use think\facade\Session;

class apicheck
{
    protected $whiteList = [
        '/',
        '/gptcms_draw/api/action/getcode',
    ];
    /**
     * 处理请求
     *
     * @param \think\Request $request
     * @param \Closure       $next
     * @return Response
     */

    public function handle($request, \Closure $next)
    { 
        $wid = $request->header('wid');
        if(!$wid) return error('缺少参数wid');
        Session::set('wid',$wid);
        $token = $request->header('token');
        $url   = strtolower($request->baseUrl()); //获取url地址, 不带域名,然后小写,
        if(in_array($url,$this->whiteList)) return $next($request);
        if(!$token) return error('无效的token');

        $platform = platform();
        if($platform == 'mpapp'){ //微信小程序
            $user = Db::table('kt_gptcms_common_user')->where([['wid', '=', $wid],['xcx_token', '=', $token]])->find();
            if(!$user) return error('无效的token');
            return $next($request);
        }else{
            $user = Db::table('kt_gptcms_common_user')->where([['wid', '=', $wid],['token', '=', $token],['expire_time','>',time()]])->find();
            if(!$user) return error('无效的token');
            Db::table('kt_gptcms_common_user')->where('id',$user['id'])->update(['expire_time'=> time() + (7*24*3600) ]);
            return $next($request);
        }
    }
}
