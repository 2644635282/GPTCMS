<?php

use think\facade\Route;

/**
 * 用户后台
 */
Route::group('user',function(){
	Route::group('desclexicon', function () {
		Route::any('list', 'user.Desclexicon/list');
		Route::any('delete', 'user.Desclexicon/delete');
		Route::any('save', 'user.Desclexicon/save');
		Route::any('importdata', 'user.Desclexicon/importData');
	});
	//风格
	Route::group('style', function () {
		Route::any('list', 'user.Style/list'); 
		Route::any('save', 'user.Style/save'); 
		Route::any('updatestatus', 'user.Style/updateStatus'); 
		Route::any('updatevipstatus', 'user.Style/updateVipStatus'); 
		Route::any('delete', 'user.Style/delete'); 
		Route::any('detail', 'user.Style/detail');
		Route::any('importdata', 'user.Style/importData'); 
	});

	Route::group('paint', function () {
		Route::any('list', 'user.Paint/list');
		Route::any('delete', 'user.Paint/delete');
		Route::any('hotstatus', 'user.Paint/hotStatus');
		Route::any('openstatus', 'user.Paint/openStatus');
		Route::any('title', 'user.Paint/title');
		Route::any('classifyset', 'user.Paint/classifySet');
		Route::any('classify', 'user.Paint/classify');
 		Route::any('classifydel', 'user.Paint/classifyDel');
 		Route::any('classifysave', 'user.Paint/classifySave');
	});
})->middleware(app\gptcms_draw\middleware\check::class);

/**
 * api
 */
Route::group('api',function(){
	Route::group('paint', function () {
		Route::any('getstyle', 'api.Paint/getStyle');
		Route::any('getranddesc', 'api.Paint/getRandDesc');
		Route::any('getextend', 'api.Paint/getExtend');
		Route::any('getsize', 'api.Paint/getSize');
		Route::any('send', 'api.Paint/send');
		Route::any('sendsame', 'api.Paint/sendSame');
		Route::any('getmsgreult', 'api.Paint/getMsgReult');
		Route::any('download', 'api.Paint/download');
		Route::any('getdownloadextend', 'api.Paint/getDownloadExtend');
	});
	Route::group('square', function () {
		Route::any('getclassfy', 'api.Square/getClassfy');
		Route::any('list', 'api.Square/list');
		Route::any('hotlist', 'api.Square/hotList');
	});

	Route::group('users', function () {
		Route::any('tplist', 'api.Users/tpList');
		Route::any('tpdel', 'api.Users/tpDel');

	});


})->middleware(app\gptcms_draw\middleware\apicheck::class);

Route::any('api/paintnotify/linkeraimj', 'api.PaintNotify/linkeraimj');
Route::any('api/paintnotify/apishopmjc2', 'api.PaintNotify/apishopmjc2');
Route::any('api/paintnotify/apishopmjc1', 'api.PaintNotify/apishopmjc1');

