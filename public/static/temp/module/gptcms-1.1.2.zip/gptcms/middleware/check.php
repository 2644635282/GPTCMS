<?php

declare (strict_types = 1);

namespace app\gptcms\middleware;
use think\facade\Db;
use think\facade\Session;

class check
{
    protected $whiteList = [
        '/',
        '/gptcms/user/index',
        '/gptcms/user/getlogininfo',
        '/gptcms/user/card/downexcel',
    ];
    /**
     * 处理请求
     *
     * @param \think\Request $request
     * @param \Closure       $next
     * @return Response
     */

    public function handle($request, \Closure $next)
    { 
        $token = $request->header('UserToken');
        // echo app('http')->getName(); //获取应用名
        $url   = strtolower($request->baseUrl()); //获取url地址, 不带域名,然后小写,
        if(in_array($url,$this->whiteList)) return $next($request);
        if(!$token) return error('缺少参数UserToken');
        $user = Db::table('kt_base_user')->where([['token', '=', $token],['expire_time','>',time()]])->find();
        if(!$user) return error('无效的UserToken');
        Db::table('kt_base_user')->where('id',$user['id'])->update(['expire_time'=> time() + (7*24*3600) ]);
        return $next($request);
        
    }
}
