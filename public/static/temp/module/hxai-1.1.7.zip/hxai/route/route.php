<?php

use think\facade\Route;

/**
 * 用户后台
 */
Route::group('user',function(){
	Route::any('/index', 'user.Index/index'); //首页
});