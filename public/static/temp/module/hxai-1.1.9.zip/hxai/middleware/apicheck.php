<?php

declare (strict_types = 1);

namespace app\hxai\middleware;
use think\facade\Db;
use think\facade\Session;

class apicheck
{
    protected $whiteList = [
        '/',
        '/hxai/api/action/getcode',
        '/hxai/api/action/login',
        '/hxai/api/sendcode',
        '/hxai/api/users/login',
        '/hxai/api/users/register',
        '/hxai/api/users/wxlogin',
        '/hxai/api/users/wxuserinfo',
        '/hxai/api/users/xcxlogin',
        '/hxai/api/users/getwebsitinfo',
        '/hxai/api/set/getwxgzh',
        '/hxai/api/set/getpc',
        '/hxai/api/set/geth5',
        '/hxai/api/set/getxcx',
        '/hxai/api/set/getminiprogram',
        '/hxai/api/set/getremind',
        '/hxai/api/set/getselfbalance',
        '/hxai/api/set/getttv',
        '/hxai/api/set/getchatmodel',
        '/hxai/api/set/getpaintmodel',
        '/hxai/api/set/getexpend',
        '/hxai/api/set/getpaintstatus',
        '/hxai/api/createchat/modelcy',
        '/hxai/api/createchat/models',
        '/hxai/api/createchat/modeldl',
        '/hxai/api/rolechat/modelcy',
        '/hxai/api/rolechat/models',
        '/hxai/api/rolechat/modeldl',
        '/hxai/api/marketing/list',
        '/hxai/api/marketing/recharge',
        '/hxai/api/marketing/vad',
        '/hxai/api/paynotify/webchat',
        '/hxai/api/share/getjssdk',
        '/hxai/api/uploadfile',
        '/hxai/api/chat/msgs',
        '/hxai/api/chat/getgrouplist',
        '/hxai/api/chat/getchatset',
        '/hxai/api/paint/getpaintset',
        '/hxai/api/hot/list',
        '/hxai/api/hot/classify'
    ];
    /**
     * 处理请求
     *
     * @param \think\Request $request
     * @param \Closure       $next
     * @return Response
     */

    public function handle($request, \Closure $next)
    { 
        $wid = $request->header('wid');
        if(!$wid) return error('缺少参数wid');
        Session::set('wid',$wid);
        $token = $request->header('token');
        $url   = strtolower($request->baseUrl()); //获取url地址, 不带域名,然后小写,
        if(in_array($url,$this->whiteList)) return $next($request);
        if(!$token) return error('无效的token');

        $platform = platform();
        if($platform == 'mpapp'){ //微信小程序
            $user = Db::table('kt_gptcms_common_user')->where([['wid', '=', $wid],['xcx_token', '=', $token]])->find();
            if(!$user) return error('无效的token');
            return $next($request);
        }else{
            $user = Db::table('kt_gptcms_common_user')->where([['wid', '=', $wid],['token', '=', $token],['expire_time','>',time()]])->find();
            if(!$user) return error('无效的token');
            Db::table('kt_gptcms_common_user')->where('id',$user['id'])->update(['expire_time'=> time() + (7*24*3600) ]);
            return $next($request);
        }
    }
}
