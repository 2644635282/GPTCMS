<?php
return [
	'syncpaint' => 1,
];