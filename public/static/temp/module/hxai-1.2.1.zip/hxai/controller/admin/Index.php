<?php
declare (strict_types = 1);

namespace app\hxai\controller\admin;
use app\hxai\controller\BaseAdmin;

class Index extends BaseAdmin
{
    public function index()
    {
    	return view();
    }
}
