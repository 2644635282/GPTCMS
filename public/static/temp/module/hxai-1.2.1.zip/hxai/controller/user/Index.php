<?php
namespace app\hxai\controller\user;

use app\BaseController;
use think\facade\Db;
use think\Request;
use think\facade\Session;

class Index extends BaseController
{
    public function index(Request $request){
        $token = Session::get('token');
        if(request()->get('token')){
            Session::set('token',request()->get('token'));
            return redirect($request->domain().$request->baseUrl());
        }
        if(!$token) return error('未登录，请先登录');
        $user = Db::table('kt_base_user')->where([['token', '=', $token],['expire_time','>',time()]])->find();
        if(!$user) return error('无效的token');
        Db::table('kt_base_user')->where('id',$user['id'])->update(['expire_time'=> time() + (7*24*3600) ]);
        $agent = site_info();
        return view('',[
            'agent' => $agent,
            'web_link' => request()->host()."/app/".app('http')->getName()."/h5?wid=".$user['id']
        ]);
    }
}