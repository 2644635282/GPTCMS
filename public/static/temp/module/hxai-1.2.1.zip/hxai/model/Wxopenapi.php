<?php 
namespace app\hxai\model;
use think\facade\Db;
use think\facade\Session;
use WebSocket\Client;
use think\facade\Cache;

class Wxopenapi
{
	static public function getToken($wid=NULL){
		$wid = $wid?:Session::get("wid");
        if(!$wid) return error('缺少必要参数wid');
        $wxgzh = Db::table('kt_gptcms_wxgzh')->where('wid', $wid)->find();
        if(!$wxgzh)return error("请配置公众号");
        $cacheName = "gptcms_access_token_".$wxgzh['appid'];
		if(!Cache::get($cacheName)){
			$res = curlGet('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$wxgzh['appid'].'&secret='.$wxgzh['appsecret']);
			$res = json_decode($res,1);
			if(!$res['access_token']){
				return '';
			}
			Cache::set($cacheName,$res['access_token'],6900);
		}

		return Cache::get($cacheName);
	}


	//公众号发送文字
	static public function send($touser,$wid,$content){
		$token = self::getToken($wid);
		$resp = curlPost("https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" .$token,
	    	json_encode([
	      		"touser"  => $touser,
	      		"msgtype"	  => "text",
	      		"text"=>[
	      			"content"=>$content
	      		]	
	    	],JSON_UNESCAPED_UNICODE)
	  	);	
	  	$arr = json_decode($resp,1);
	  	return $arr;
	}
}