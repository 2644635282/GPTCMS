<?php 
namespace app\hxai\controller;

use think\facade\Db;
use app\BaseController;
use think\facade\Log;
use app\hxai\model\Wxopenapi;
include "../extend/Qywxcypto/WXBizMsgCrypt.php";

/**
* 公众号回调 登录操作
**/
class Callback extends BaseController{
    public function index(){
        if(isset($_GET['echostr'])){
            $setting = Db::table("kt_gptcms_wxgzh")->select()->toArray();
            foreach ($setting as $key => $value) {
                $echostr = $_GET['echostr'];
                $signature = $_GET["signature"];
                $timestamp = $_GET["timestamp"];
                $nonce = $_GET["nonce"];    
                $token = $value["token"];
                $tmpArr = array($token, $timestamp, $nonce);
                sort($tmpArr);
                $tmpStr = implode( $tmpArr );
                $tmpStr = sha1( $tmpStr );
                if( $tmpStr == $signature ){
                    echo $echostr;
                    exit();
                }else{
                    return false;
                }
            }
        }else{
            $xml = preg_replace("/[\n\s]/", '', file_get_contents('php://input'));
            $arr = $this->xml_to_array($xml);
            if(!isset($arr["EventKey"])){
                echo "success";
                die;
            }
            if($arr["Event"] == "SCAN"){
                $EventKey = $arr["EventKey"];
            }else if($arr["Event"] == "subscribe"){
                $EventKey = substr($arr["EventKey"], 8);
            }
            $random = Db::table("kt_gptcms_random")->where(["random"=>$EventKey])->whereTime("ctime",">=",date("Y-m-d"))->find();
            if($random["openid"]){
                echo "success";
                die;
            }
            $wid = $random["wid"];
            $data["openid"] = $_GET["openid"];
            Db::table("kt_gptcms_random")->where(["id"=>$random["id"]])->save($data);
            $res = Wxopenapi::send($_GET["openid"],$wid,"恭喜您，登录成功！请回到网页继续使用！");
            Log::error($res);
        }
        echo "success";
        die;
    }
    
    function xml_to_array($xml){
      $res = simplexml_load_string($xml, 'SimpleXmlElement', LIBXML_NOCDATA);
      return json_decode(json_encode($res), true);
    }
}