<?php

namespace app\hxai\controller\api;
use app\hxai\controller\BaseApi;
use think\facade\Db;
use think\facade\Session;
use Ktadmin\Tencent\Aichest;
use Ktadmin\Ali\Ai as AliAi;
use app\hxai\model\SecurityModel;
use app\hxai\model\CommonModel;

class Tool extends BaseApi
{
	//语音转文字
	public function videoTtext()
	{
		$wid = Session::get('wid');
		$config = $this->getTencentaiConfig($wid);
		if(!$config || !$config['secret_id'] || !$config['secret_key']) return error("转换失败, 请联系管理员");
		$data = $this->req->post("upfile");
		// $data = base64_encode(file_get_contents(root_path()."public/static/demo/static/ddd.mp3"));
		$ai = new Aichest($config['secret_id'],$config['secret_key']);
		$ai->SourceType = 1;
		$ai->VoiceFormat = "wav";
		$task = $ai->SentenceRecognition(json_encode($data));
		if(isset($task->Error)) return error("转换失败, 请联系管理员");
		return success("转换成功",$task->Result);
	}

	private function getTencentaiConfig($wid)
	{
		$config = Db::table('kt_gptcms_tencentai_config')->field('secret_id,secret_key')->where('wid',$wid)->find();
		if(!$config || !$config['secret_id'] || !$config['secret_key']){
			$user = Db::table("kt_base_user")->find($wid);
			$config = Db::table('kt_base_tencentai_config')->field('secret_id,secret_key')->where('uid',$user['agid'])->find();
		}
		return $config;
	}
	//文字转语音 阿里云
	public function textTvideo()
	{
		$wid = Session::get('wid');
		$config = $this->getAliaiConfig($wid);

		if(!$config || !$config['accesskey_id'] || !$config['accesskey_secret'] || !$config['appkey']) return error("生成失败, 请联系管理员");
		$content = $this->req->param("content");
		$content = str_replace(PHP_EOL,'',$content);
		if(!$content) return error("文本不可为空");
		$content = str_replace('<br/>', '', $content);
		$content = str_replace('，', '', $content);
		$content = str_replace('。', '', $content);
		// $data = base64_encode(file_get_contents(root_path()."public/static/demo/static/ddd.mp3"));
		// 		if(strlen($content) > 300) $content = substr($content, 0, 300);
		$path = root_path().'public/storage/aliai';
		if(!is_dir($path)) mkdir($path,0777,true);
		$filename = time().'_'.rand(1,99).'.mp3';
		$ai = new AliAi($config['accesskey_id'],$config['accesskey_secret'],$config['appkey']);
		$res = $ai->processGETRequest($content,$path."/".$filename,"mp3");
		if(!$res) return error("转换失败, 请联系管理员");
		$filename = basename($res);
		$file = $this->req->domain().'/storage/aliai/'.$filename;
		return success("转换成功",$file);
	}
	//文字转语音 讯飞
	public function textTvideoXf()
	{
		$url = $this->req->domain();
		$wid = Session::get('wid');
		$config = $this->getTtsConfing();
		if(!$config || !$config['appid'] || !$config['secret'] || !$config['key']) return error("生成失败, 请联系管理员");
		$content = $this->req->param("content");
		$content = str_replace(PHP_EOL,'',$content);
		if(!$content) return error("文本不可为空");
		$content = str_replace('<br/>', '', $content);
		$content = str_replace('，', '', $content);
		$content = str_replace('。', '', $content);
		if(strlen($content) > 8000) $content = substr($content, 0, 8000);
		$file = TtsModel::authentication($config['appid'],$config['key'],$config['secret'],$content);
		$file = ltrim($file,'.');

		return success("转换成功",$url.$file);
	}

	public function getTtsConfing(){
		$wid = Session::get("wid");
		$config = Db::table('kt_gptcms_tts_config')->where('wid',$wid)->find();

		return $config;
	}

	private function getAliaiConfig($wid)
	{
		$config = Db::table('kt_gptcms_aliai_config')->field('accesskey_id,accesskey_secret,region,appkey')->where('wid',$wid)->find();
		if(!$config || !$config['accesskey_id'] || !$config['accesskey_secret']){
			$user = Db::table("kt_base_user")->find($wid);
			$config = Db::table('kt_base_aliai_config')->field('accesskey_id,accesskey_secret,region,appkey')->where('uid',$user['agid'])->find();
		}
		return $config;
	}
	//绘画文字审核
	public function paintTextCheck()
	{
		$wid = Session::get('wid');
		$text = $this->req->param('text');
		$chatmodel = $this->req->param('chatmodel');
		$user = $this->user;
		if($user['status'] != 1){
            return error("账号已停用");
        }
        $vip = 0;
        if(strtotime($user['vip_expire']) > time()){ //会员未到期
            $vip = 1;
        }else{ //会员到期
        	if(!$chatmodel){
        		$config['channel'] = Db::table('kt_gptcms_gptpaint_config')->where('wid',$wid)->value('channel');
	            switch ($config['channel']) {
	                case 1:
	                    $chatmodel = 'yjai';
	                    break;

	                case 2:
	                    $chatmodel = 'replicate';
	                    break;

	                case 3:
	                    $chatmodel = 'gpt35';
	                    break;
	                case 4:
	                    $chatmodel = 'api2d35';
	                    break;
	                case 5:
	                    $chatmodel = 'sd';
	                    break;
	                default:
	                    $chatmodel = 'sd';
	                    break;
	            }
        	}
        	$expend = CommonModel::getExpend('paint',$chatmodel);//获取消耗条数
            if($user['residue_degree'] < $expend){ //余数不足
                $zdz_remind = Db::table('kt_gptcms_system')->where('wid',$wid)->value('zdz_remind');
                return error($zdz_remind ?: "剩余条数不足");
            }
        }
		$cs = SecurityModel::check($text,1);
		return success("检查结果",$cs);
	}

	//对话文字审核
	public function textCheck()
	{
		$wid = Session::get('wid');
		$text = $this->req->param('text');
		$user = $this->user;
		if($user['status'] != 1){
            return error("账号已停用");
        }
        $vip = 0;
        if(strtotime($user['vip_expire']) > time()){ //会员未到期
            $vip = 1;
        }else{ //会员到期
        	$chatmodel = $this->req->param('chatmodel');
        	if(!$chatmodel){
        		$config['channel'] = Db::table('kt_gptcms_gpt_config')->where('wid',$wid)->value('channel');
	            switch ($config['channel']) {
	                case 1:
	                    $chatmodel = 'gpt35';
	                    break;

	                case 2:
	                    $chatmodel = 'api2d35';
	                    break;

	                case 7:
	                    $chatmodel = 'linkerai';
	                    break;

	                case 8:
	                    $chatmodel = 'gpt4';
	                    break;

	                case 9:
	                    $chatmodel = 'api2d4';
	                    break;
	                
	                default:
	                    $chatmodel = 'gpt35';
	                    break;
	            }
        	}
        	$expend = CommonModel::getExpend('chat',$chatmodel);//获取消耗条数
            if($user['residue_degree'] < $expend){ //余数不足
                $zdz_remind = Db::table('kt_gptcms_system')->where('wid',$wid)->value('zdz_remind');
                return error($zdz_remind ?: "剩余条数不足");
            }
        }
        $model_id = $this->req->param('model_id');
        $type = $this->req->param('type',"chat");
        switch ($type) {
        	case 'chat':

        		break;
        	case 'createchat':
        		$cmodel = Db::table('kt_gptcms_cmodel')->find($model_id);
        		if(!$cmodel) return error('模型不存在');
        		if($cmodel['status'] != 1) return error('模型不可用');
        		if($cmodel['vip_status'] == 1 && $vip == 0) return error("当前模型仅VIP可用");
        		break;
        	case 'rolechat':
        		$jmodel = Db::table('kt_gptcms_jmodel')->find($model_id);
        		if(!$jmodel) return error('模型不存在');
        		if($jmodel['status'] != 1) return error('模型不可用');
        		if($jmodel['vip_status'] == 1 && $vip == 0) return error("当前模型仅VIP可用");
        		break;
        	
        }
        
		$cs = SecurityModel::check($text,1);
		return success("检查结果",$cs);
	}
	private function getBaiduaiConfig($wid)
	{
		$config = Db::table('kt_gptcms_baiduai_config')->field('apikey,secretkey,appid')->where('wid',$wid)->find();
		if(!$config || !$config['apikey'] || !$config['secretkey']){
			$user = Db::table("kt_base_user")->find($wid);
			$config = Db::table('kt_base_baiduai_config')->field('apikey,secretkey,appid')->where('uid',$user['agid'])->find();
		}
		return $config;
	}
}