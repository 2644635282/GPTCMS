<?php 
namespace app\hxai\model;
use think\facade\Db;
use think\facade\Session;


class CommonModel
{
	//获取消耗条数 
	// $type  chat(对话)  paint 绘画
	// $model 模型
 	static public function getExpend($type,$model)
	{
		$expend = 1;
		$wid = Session::get("wid");
		switch ($type) {
			case 'chat':
				$res =  Db::table('kt_gptcms_chatmodel_set')->where('wid',$wid)->json(["gpt35","gpt4","linkerai","api2d35","api2d4"])->find();
				if($res && $res[$model]) $expend = $res[$model]['expend'] ?: 1;
				break;
			case 'paint':
				$res = Db::table('kt_gptcms_paintmodel_set')->where('wid',$wid)->json(["sd","yjai","gpt35","api2d35","replicate","linkerai_mj"])->find();
				if($res && $res[$model]) $expend = $res[$model]['expend'] ?: 1;
				break;
		}
		
		return $expend;
	}
}