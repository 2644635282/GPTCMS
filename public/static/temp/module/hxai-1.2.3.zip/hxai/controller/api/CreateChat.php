<?php

namespace app\hxai\controller\api;
use app\hxai\controller\BaseApi;
use app\hxai\model\CommonModel;
use think\facade\Db;
use think\facade\Session;

class CreateChat extends BaseApi
{
    /**
     * 分类
     */
    public function modelcy()
    {
        $wid = Session::get('wid');
        $res = Db::table("kt_gptcms_cmodel_classify")->field('id,title,sort')->where('wid',$wid)->order('sort','desc')->select();
        return success('分类',$res);
    }

    /**
     * 创作模型
     */
    public function models()
    {
        $wid = Session::get('wid');
        $page = $this->req->param('page')?:1;
        $size = $this->req->param("size")?:10;
        $classify_id = $this->req->param('classify_id');
        $title = $this->req->param('title','');
        $res = Db::table("kt_gptcms_cmodel")->where(['wid'=>$wid,'status'=>1])->field('id,title,tp_url,desc,bz,xh,vip_status,status,c_time,classify_id,content,hint_content,defalut_question,defalut_reply');

        if($classify_id) $res->where('classify_id',$classify_id);
        if($title) $res->where('title','like',"%{$title}%");

        $data = [];
        $data['page'] = $page;
        $data['size'] = $size;
        $data['count'] = $res->count();
        $data['item'] = $res->page($page,$size)->order('xh','desc')->filter(function($r){
            $r['classify'] = Db::table("kt_gptcms_cmodel_classify")->value('title');
            return $r;
        })->select();

        return success('模型列表',$data);
    }

    /**
     * 模型详情
     */
    public function modeldl()
    {
        $wid = Session::get('wid');
        $id = $this->req->param('id');
        if(!$id) return error('请选择模型');
        $res = Db::table("kt_gptcms_cmodel")->field('id,title,tp_url,desc,bz,xh,vip_status,status,c_time,classify_id,content,hint_content,defalut_question,defalut_reply')->where('wid',$wid)->find($id);

        return success('模型详情',$res);
    }

    /**
     * 模型是否可用
     */
    public function isHave()
    {
        $wid = Session::get('wid');
        $model_id = $this->req->param('model_id');
        $user = $this->user;
        if(!$model_id) return error('请选择模型',['have'=>0]);
        if(!$user) return error('用户不存在',['have'=>0]);

        $cmodel = Db::table('kt_gptcms_cmodel')->find($model_id);
        if(!$cmodel) return error('模型不存在',['have'=>0]);
        if($cmodel['status'] != 1) return error('模型不可用',['have'=>0]);

        $vip = 0;
        if(strtotime($user['vip_expire']) > time()){ //会员未到期
            $vip = 1;
        }
        //是VIP模型的，仅VIP能使用
        if($cmodel['vip_status'] == 1){
            if($vip == 0) return error('当前模型仅VIP可用',['have'=>0]);
        }
        return success('可以使用',['have'=>1]);
    }

    /**
     * 历史记录
     */
    public function msgs()
    {
        $wid = Session::get('wid');
        $user = $this->user;
        $model_id = $this->req->param('model_id');
        if(!$model_id) return error('请选择模型');
        $where = [];
        $where[] = ['wid','=',$wid];
        $where[] = ['common_id','=',$user['id']];
        $where[] = ['model_id','=',$model_id];

        $msgList = Db::table('kt_gptcms_create_msg')->field('id,message,un_response')->where($where)->order('id asc')->select();
        $msgs = [];
        foreach ($msgList as $key => $msg) {
            $msgs[] = [
                'role' => '我',
                'content' => $msg['message']
            ];
            $msgs[] = [
                'role' => '助手',
                'content' => $msg['un_response']
            ];
        }
        return success('获取成功',$msgs);
    }

    /**
     * 清除历史记录
     */
    public function delMsgs()
    {
        $wid = Session::get('wid');
        $user = $this->user;
        $model_id = $this->req->param('model_id');
        if(!$user) return error('用户不存在');
        if(!$model_id) return error('请选择模型');

        Db::table('kt_gptcms_create_msg')->where(['wid'=>$wid,'common_id'=>$user['id'],'model_id'=>$model_id])->delete();
        return success('操作成功，已删除');
    }

	/**
     * send
     */
    public function send()
    {
        header('Content-Type: text/event-stream');
        header('Cache-Control: no-cache');
        header('Connection: keep-alive');
        header('X-Accel-Buffering: no');

        $wid = Session::get('wid');
        $user = $this->user;
        if($user['status'] != 1){
            $this->outError('账号已停用');
        }

        $model_id = $this->req->param('model_id');
        $cmodel = Db::table('kt_gptcms_cmodel')->find($model_id);
        if(!$cmodel) $this->outError('模型不存在');
        if($cmodel['status'] != 1) $this->outError('模型不可用');

        $chatmodel = $this->req->param('chatmodel');
        if(!$chatmodel){
            $config['channel'] = Db::table('kt_gptcms_gpt_config')->where('wid',$wid)->value('channel');
            switch ($config['channel']) {
                case 1:
                    $chatmodel = 'gpt35';
                    break;

                case 2:
                    $chatmodel = 'api2d35';
                    break;

                case 7:
                    $chatmodel = 'linkerai';
                    break;

                case 8:
                    $chatmodel = 'gpt4';
                    break;

                case 9:
                    $chatmodel = 'api2d4';
                    break;
                
                default:
                    $chatmodel = 'gpt35';
                    break;
            }
        }
        $expend = CommonModel::getExpend('chat',$chatmodel);//获取消耗条数
        $vip = 0;
        if(strtotime($user['vip_expire']) > time()){ //会员未到期
            $vip = 1;
        }else{ //会员到期
            if($user['residue_degree'] < $expend){ //余数不足
                $zdz_remind = Db::table('kt_gptcms_system')->where('wid',$wid)->value('zdz_remind');
                $this->outError($zdz_remind?:'剩余条数不足');
            }
        }
        
        //是VIP模型的，仅VIP能使用
        if($cmodel['vip_status'] == 1){
            if($vip == 0) $this->outError('当前模型仅VIP可用');
        }
        
        $message = $this->req->param('message');
        if(!$message){
            $this->outError('请输入您的问题');
        }
        $message = urldecode($message);
        $lang = $this->req->param('lang','简体中文');

        // 连续对话需要带着上一个问题请求接口
        if($message == '继续' || $message == 'go on'){
            $lastMsg = Db::table('kt_gptcms_create_msg')->where([
                ['wid', '=', $wid],
                ['common_id', '=', $user['id']],
                ['model_id', '=', $model_id]
            ])->order('id desc')->find();
            // 如果超长，就不关联上下文了
            if ($lastMsg && (mb_strlen($lastMsg['make_message']) + mb_strlen($lastMsg['un_response']) + mb_strlen($message) < 3800)) {
                $messages[] = [
                    'role' => 'user',
                    'content' => $lastMsg['make_message']
                ];
                $messages[] = [
                    'role' => 'assistant',
                    'content' => $lastMsg['un_response']
                ];
            }
            $make_message = $message;
        }else{
            $make_message = str_replace('[TARGETLANGGE]', $lang, $cmodel['content']);
            $make_message = str_replace('[PROMPT]', $message, $make_message);
        }
        $messages[] = [
            'role'=>'user',
            'content'=>$make_message
        ];

        //返回的文字
        $response = ''; 
        $un_response = '';
        //不完整的数据
        $imperfect = '';
        $callback = function($ch, $data) use ($message,$wid,$user,$vip,$cmodel,$make_message,$expend) {
            //$ktadmin = new \Ktadmin\Chatgpt\Ktadmin();
            global $response;
            global $un_response;
            global $imperfect;
            $dataLength = strlen($data);
            //如果存在不完整的数据
            if($imperfect){
                $data = $imperfect . $data;
                $imperfect = '';
            }else{
                if (substr($data, -1) !== "\n") {
                    $imperfect = $data;
                    return $dataLength;
                }
            }
            
            $complete = @json_decode($data);
            if(isset($complete->error)){
                $this->outError($complete->error->message?:$complete->error->code);
            }elseif(@$complete->object == 'error'){
                $this->outError($complete->message);
            }
            $un_word = parseData($data);
            $word = str_replace("\n", '<br/>', $un_word);
            $word = str_replace(" ", '&nbsp;', $word);
            if($complete){//一次性完整输出
                if (!empty($un_word)) {
                    Db::table('kt_gptcms_create_msg')->insert([
                        'wid' => $wid,
                        'common_id' => $user['id'],
                        'model_id' => $cmodel['id'],
                        'un_message' => $message,
                        'message' => $message,
                        'make_message' => $make_message,
                        'un_response' => $un_word,
                        'response' => $word,
                        'total_tokens' => mb_strlen($make_message) + mb_strlen($un_word),
                        'c_time' => time()
                    ]);
                    //如果不是会员扣费
                    if($vip != 1){
                        Db::table('kt_gptcms_common_user')->where('id',$user['id'])->dec('residue_degree',$expend)->update();
                    }
                    echo $un_word;
                }
                ob_flush();flush();
            }else{//流式
                if(strpos($un_word, 'data: [DONE]') !== false){
                    $un_word = str_replace("data: [DONE]","",$un_word);
                    $word = str_replace("data:&nbsp;[DONE]","",$word);
                    $un_response .= $un_word;
                    $response .= $word;
                    if (!empty($un_response)) {
                        Db::table('kt_gptcms_create_msg')->insert([
                            'wid' => $wid,
                            'common_id' => $user['id'],
                            'model_id' => $cmodel['id'],
                            'un_message' => $message,
                            'message' => $message,
                            'make_message' => $make_message,
                            'un_response' => $un_response,
                            'response' => $response,
                            'total_tokens' => mb_strlen($make_message) + mb_strlen($un_response),
                            'c_time' => time()
                        ]);
                        //如果不是会员扣费
                        if($vip != 1){
                            Db::table('kt_gptcms_common_user')->where('id',$user['id'])->dec('residue_degree',$expend)->update();
                        }
                        $un_response = '';
                        $response = '';
                    }
                    echo $un_word;ob_flush();flush();
                }else{
                    $un_response .= $un_word;
                    $response .= $word;
                    echo $un_word;ob_flush();flush();
                }
            }
            return $dataLength;
        };

        $agid = Db::table('kt_base_user')->where('id',$wid)->value('agid');
        if(!$agid){
            $agid = Db::table('kt_base_agent')->where('isadmin',1)->value('id');
        }
        $base_config = Db::table('kt_base_gpt_config')->json(['openai','api2d'])->where('uid',$agid)->find();
        $base_aiconfig = $base_config['openai'];

        $config = Db::table('kt_gptcms_gpt_config')->json(['openai','api2d','linkerai','gpt4','api2d4'])->where('wid',$wid)->find();
        if($config){
            // if($config['channel'] == 2){
            //     $aiconfig = $config['api2d'];
            //     $ktadmin = new \Ktadmin\Chatgpt\Ktadmin(['channel'=>2,'api_key'=>$aiconfig['forward_key'],'diy_host'=>'']);
            //     $ktadmin->chat()->sendText($messages, $callback,['temperature'=>$aiconfig['temperature'],'max_tokens'=>$aiconfig['max_tokens'],'model'=>$aiconfig['model'],'stream'=>true]);
            // }elseif($config['channel'] == 7){
            //     $aiconfig = $config['linkerai'];
            //     $ktadmin = new \Ktadmin\LinkerAi\Ktadmin(['channel'=>7,'api_key'=>$aiconfig['api_key']]);
            //     $ktadmin->chat()->sendText($messages, $callback,['temperature'=>$aiconfig['temperature'],'max_tokens'=>$aiconfig['max_tokens'],'model'=>$aiconfig['model'],'stream'=>true]);
            // }else{
            //     $aiconfig = $config['openai'];
            //     $ktadmin = new \Ktadmin\Chatgpt\Ktadmin(['channel'=>1,'api_key'=>$aiconfig['api_key'],'diy_host'=>$base_aiconfig['diy_host']]);
            //     $ktadmin->chat()->sendText($messages, $callback,['temperature'=>$aiconfig['temperature'],'max_tokens'=>$aiconfig['max_tokens'],'model'=>$aiconfig['model'],'stream'=>true]);
            // }

            switch ($chatmodel) {
                case 'gpt35':
                    $aiconfig = $config['openai'];
                    $ktadmin = new \Ktadmin\Chatgpt\Ktadmin(['channel'=>1,'api_key'=>$aiconfig['api_key'],'diy_host'=>$aiconfig['diy_host']?:$base_aiconfig['diy_host']]);
                    $ktadmin->chat()->sendText($messages, $callback,['temperature'=>$aiconfig['temperature'],'max_tokens'=>$aiconfig['max_tokens'],'model'=>'gpt-3.5-turbo-0613','stream'=>true]);
                    break;

                case 'gpt4':
                    $aiconfig = $config['gpt4'];
                    $ktadmin = new \Ktadmin\Chatgpt\Ktadmin(['channel'=>1,'api_key'=>$aiconfig['api_key'],'diy_host'=>$aiconfig['diy_host']?:$base_aiconfig['diy_host']]);
                    $ktadmin->chat()->sendText($messages, $callback,['temperature'=>$aiconfig['temperature'],'max_tokens'=>$aiconfig['max_tokens'],'model'=>'gpt-4-0613','stream'=>true]);
                    break;
                
                case 'api2d35':
                    $aiconfig = $config['api2d'];
                    $ktadmin = new \Ktadmin\Chatgpt\Ktadmin(['channel'=>2,'api_key'=>$aiconfig['forward_key'],'diy_host'=>'']);
                    $ktadmin->chat()->sendText($messages, $callback,['temperature'=>$aiconfig['temperature'],'max_tokens'=>$aiconfig['max_tokens'],'model'=>'gpt-3.5-turbo-0613','stream'=>true]);
                    break;

                case 'api2d4':
                    $aiconfig = $config['api2d4'];
                    $ktadmin = new \Ktadmin\Chatgpt\Ktadmin(['channel'=>2,'api_key'=>$aiconfig['forward_key'],'diy_host'=>'']);
                    $ktadmin->chat()->sendText($messages, $callback,['temperature'=>$aiconfig['temperature'],'max_tokens'=>$aiconfig['max_tokens'],'model'=>'gpt-4-0613','stream'=>true]);
                    break;

                case 'linkerai':
                    $aiconfig = $config['linkerai'];
                    $ktadmin = new \Ktadmin\LinkerAi\Ktadmin(['channel'=>7,'api_key'=>$aiconfig['api_key']]);
                    $ktadmin->chat()->sendText($messages, $callback,['temperature'=>$aiconfig['temperature'],'max_tokens'=>$aiconfig['max_tokens'],'model'=>$aiconfig['model'],'stream'=>true]);
                    break;
            }
        }else{
            $this->outError('未检查到配置信息');
        }
        exit();
    }

    private function outError($msg)
    {
        echo 'data:[error]' . $msg . '\n\n';
        ob_flush();
        flush();
        exit;
    }
    
}
